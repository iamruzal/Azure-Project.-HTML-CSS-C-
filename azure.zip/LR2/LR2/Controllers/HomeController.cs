﻿using LR2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace LR2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        private int _counter = 0;
        public IActionResult TaskFirst()
        {
            return View();
        }
        public IActionResult TaskSecond()
        {
            return View();
        }
        public IActionResult TaskThird()
        {
            return View();
        }
        [HttpPost]
        public IActionResult TaskFirst(string First, string Second, string Third, string Chetire)
        {
            double perv = Convert.ToDouble(First);
            double vtor = Convert.ToDouble(Second);
            double tri = Convert.ToDouble(Third);
            double ch = Convert.ToDouble(Chetire);
            int c = 0;

            if (perv < 0)
            {
                c += 1;
            }
            if (vtor < 0)
            {
                c += 1;
            }
            if (tri < 0)
            {
                c += 1;
            }
            if (ch < 0)
            {
                c += 1;
            }
            ViewBag.H = c;
            return View();
        }
        [HttpPost]
        public IActionResult TaskSecond(string n, string k)
        {
            int ink = Convert.ToInt32(n);
            int kol = Convert.ToInt32(k);
            int[,] array = new int[5, 5];
            Random random = new Random();

            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    array[i, j] = random.Next(10);
                    ViewBag.Generator += array[i, j] + "\t";

                }
                ViewBag.Generator += "\n";
            }
            for (int i = 0; i < 5; i++)
            {
                int maxLine = array[i, 0];
                for (int j = 0; j < 5; j++)
                {
                    if (array[i, j] > maxLine)
                    {
                        maxLine = array[i, j];
                    }
                }
                ViewBag.gg += (i + 1 + " Строка. " + " Максимальное в ней значение = " + maxLine);
                ViewBag.gg += "\n";

            }
            for (int i = 0; i < 5; i++)
            {
                int minLine = array[0, 0];
                for (int j = 0; j < 5; j++)
                {

                    if (array[j, i] < minLine)
                    {
                        minLine = array[j, i];
                    }
                }
                ViewBag.ff += (i + 1 + " Столбец. " + " Минимальное в нем значение = " + minLine);
                ViewBag.ff += "\n";

            }

            return View();
        }
        [HttpPost]
        public IActionResult TaskThird(string nn, string kk)
        {
            string ss = "";
            double arifm = 0;
            Random rnd = new Random();
            int COLUMN = 5;
            int ROW = 5;
            double[,] mas = new double[COLUMN, ROW];
            double[] tmpMas = new double[COLUMN];
            for (int i = 0; i < COLUMN; i++)
            {
                for (int j = 0; j < ROW; j++)
                {
                    mas[i, j] = rnd.Next(1, 10);
                    ss += mas[i, j] + "\t";
                }
                ss += "\n";
            }
            ViewBag.Vipolnit += ($"Массив = \n" + ss);
            for (int j = 0; j < ROW; j++)
            {
                for (int i = 0; i < COLUMN; i++)
                {
                    tmpMas[i] = mas[i, j];
                }
                ViewBag.jj+= $"\nМинимальное значение столбца  = {tmpMas.Min()}";

                arifm += tmpMas.Min();
            }
            ViewBag.qq += ($"\nСреднее арифметическое: " + arifm / ROW);
            return View();

        }
    }
}
